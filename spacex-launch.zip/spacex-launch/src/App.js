import React, { Component } from "react";

import { CardList } from "./components/card-list/card-list.component.js";
import { CardFilter } from "./components/card-filters/card-filter.js";

import "./App.css";

class App extends Component {
  constructor() {
    super();

    this.state = {
      spacexdata: [],
      spacexdata2: [],
      loading: true,
    };
  }

  componentDidMount() {
    fetch(
      "https://api.spacexdata.com/v3/launches?limit=50&amp;launch_success=true"
    )
      .then((response) => response.json())
      .then((users) =>
        this.setState({ spacexdata: users, spacexdata2: users, loading: false })
      );
  }

  onSearchChange = (event) => {
    this.setState({ searchField: event.target.value });
  };

  filterbutton = async (number) => {
    await this.setState({ spacexdata: this.state.spacexdata2 });

    const fltdata = this.state.spacexdata.filter((flt) =>
      flt.launch_year.includes(number)
    );
    this.setState({ spacexdata: fltdata });
  };
  suclanch = async (sucla) => {
    console.log(sucla);
    await this.setState({ spacexdata: this.state.spacexdata2 });

    var sucdata = this.state.spacexdata.filter((flt) =>
      flt.launch_success.toString().includes(sucla)
    );
    this.setState({ spacexdata: sucdata });
  };

  sucland = async (suclan) => {};

  render() {
    const { spacexdata, loading } = this.state;

    return (
      <div className="container-fluid" style={{ backgroundColor: "#E8E8E8" }}>
        <h2>
          <b>Space launch programs</b>
        </h2>
        <div className="row">
          <div className="col-lg-2">
            <CardFilter
              flt={this.filterbutton}
              sltf={this.suclanch}
              slatf={this.sucland}
            />
          </div>

          <div className="col-lg-10">
            <div className="cds">
              <CardList monsters={spacexdata} loading={loading} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
