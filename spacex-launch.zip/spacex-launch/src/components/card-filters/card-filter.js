import React from "react";

import "./card-filter.css";

export const CardFilter = ({ flt, sltf, slatf }) => {
  return (
    <div className="card-filter" style={{ backgroundColor: "white" }}>
      <div className=" shadow ml-2 mt-0">
        <h3>
          <b>Filters</b>{" "}
        </h3>
      </div>
      <div className="d-flex justify-content-center">
        <b
          style={{
            borderBottom: "1px solid grey",
            marginLeft: "20px",
            marginRight: "20px",
            height: "40px",
            width: "200px",
            paddingLeft: "30px",
            alignText: "center",
          }}
        >
          Launch year
        </b>
      </div>

      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2006")}>
          2006
        </button>
        <button className=" mr-2" onClick={() => flt("2007")}>
          2007
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2008")}>
          2008
        </button>
        <button className="mr-2" onClick={() => flt("2009")}>
          2009
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2010")}>
          2010
        </button>
        <button className="mr-2" onClick={() => flt("2011")}>
          2011
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2012")}>
          2012
        </button>
        <button className="mr-2" onClick={() => flt("2013")}>
          2013
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2014")}>
          2014
        </button>
        <button className="mr-2" onClick={() => flt("2015")}>
          2015
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2016")}>
          2016
        </button>
        <button className="mr-2" onClick={() => flt("2017")}>
          2017
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => flt("2018")}>
          2018
        </button>
        <button className="mr-2" onClick={() => flt("2019")}>
          2019
        </button>
      </div>
      <div className="d-flex ml-2 mt-3">
        <button className="mr-3" onClick={() => flt("2018")}>
          2020
        </button>{" "}
      </div>
      <div className="d-flex justify-content-center">
        <b
          style={{
            borderBottom: "2px solid grey",
            height: "30px",
            marginTop: "3%",
          }}
        >
          Successful Launch
        </b>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => sltf("true")}>
          true
        </button>
        <button className="mr-2" onClick={() => sltf("false")}>
          false
        </button>
      </div>
      <div className="d-flex justify-content-center">
        <b
          style={{
            borderBottom: "2px solid grey",
            height: "30px",
            marginTop: "3%",
          }}
        >
          Successful Landing
        </b>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => slatf("true")}>
          true
        </button>
        <button className="mr-2" onClick={() => slatf("false")}>
          false
        </button>
      </div>
    </div>
  );
};
