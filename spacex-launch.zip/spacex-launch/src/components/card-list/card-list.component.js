import React from "react";

import "./card-list.styles.css";

export const CardList = (props) => {
  if (props.loading) {
    return <h2>Loading...</h2>;
  }
  if (props.monsters.length === 0) {
    return <h2>No data found !</h2>;
  }
  return (
    <div className="row">
      {props.monsters.map((user, i) => (
        <div
          class="card mb-5 ml-3"
          style={{ width: "240px", borderRadius: "10px" }}
        >
          <img
            class="card-img-top mr-2"
            src={user.links.mission_patch}
            style={{
              marginLeft: "10%",
              marginRight: "10%",
              marginTop: "5%",
              width: "80%",
              backgroundColor: "#E8E8E8",
            }}
            alt="..."
          />
          <div className="card-body">
            <div>
              {" "}
              <h5 style={{ color: "blue" }}>
                {" "}
                <b>
                  {user.mission_name} &nbsp; #{user.flight_number}{" "}
                </b>{" "}
              </h5>
            </div>
            <div>
              <h5>
                {" "}
                <b>Mission Ids: </b>{" "}
                <ul>
                  <li style={{ color: "blue" }}>{user.mission_id}</li>
                </ul>
              </h5>
            </div>
            <div>
              <h6>
                <b>Launch Year </b> &nbsp;:{" "}
                <b style={{ color: "blue" }}> {user.launch_year} </b>{" "}
              </h6>
            </div>
            <div>
              <h6>
                <b>Sucessful Launch</b> &nbsp;:{" "}
                <b style={{ color: "blue" }}>
                  {" "}
                  {user.launch_success.toString()}{" "}
                </b>{" "}
              </h6>
            </div>
            <div>
              <h6>
                <b>Sucessful Loading</b> &nbsp;:{" "}
                <b style={{ color: "blue" }}>true</b>{" "}
              </h6>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
